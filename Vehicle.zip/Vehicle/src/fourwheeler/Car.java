package fourwheeler;

import vehicle.Fourwheeler;

public class Car extends Fourwheeler{
	int speed=200;
	int seats=4;
	public void seater() {
		System.out.println("i am "+seats+"seater");
	}
	public void speed() {
		System.out.println("my speed is"+speed);
	}
	
}
