package fourwheeler;

public class Electric_car extends Car {
	int mileage=25;
	private int no;
	private String name;
	public void mileage() {
		System.out.println("my mileage is"+mileage);
	}
	
//	getter setter for id
	public int getNo(){
		return no;
	}
	 public void setNo(int no){
		 this.no=no;
	 }
//	 getter setter for name
	 public String getname(){
			return name;
		}
		 public void setname(String name){
			 this.name=name;
		 }
}
