package fourwheeler;

import vehicle.Vehicle;

public class Minibus extends Vehicle {
	int speed=200;
	int seats=20;
	public void seater() {
		System.out.println("i am "+seats+"seater");
	}
	public void speed() {
		System.out.println("my speed is"+speed);
	}
	
}
