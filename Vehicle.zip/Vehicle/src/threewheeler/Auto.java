package threewheeler;

import vehicle.Threewheeler;

public class Auto extends Threewheeler {
	int tyreCount=3;
	int speed=90;
	int seats=4;
	private int no;
	private String name;
	public void seater() {
		System.out.println("i am "+seats+"seater");
	}
	public void speed() {
		System.out.println("my speed is "+speed);
	}
//getter setter for id	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no=no;
	}
//getter setter for name
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	
	
}
