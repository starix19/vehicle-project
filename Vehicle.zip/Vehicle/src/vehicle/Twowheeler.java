package vehicle;

public class Twowheeler extends Vehicle {
	 public void start() {
		System.out.println("i am starting");
	}
	 public void stop() {
		System.out.println("i am stoping");
	}
}
