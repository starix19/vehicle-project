package vehicle;

import fourwheeler.Car;
import fourwheeler.Diesel;
import fourwheeler.Electric_car;
import fourwheeler.Petrol_car;
import twowheeler.Bike;
import twowheeler.Electric;
import twowheeler.Petrol;

public class Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// vehicle all objects....
		Twowheeler t1=new Twowheeler();
		Threewheeler t2=new Threewheeler();
		Fourwheeler t3=new Fourwheeler();
		
	t1.start();
	t1.stop();
	
	t2.start();
	t2.stop();
	
	t3.start();
	t3.stop();	
	
//bike all objects..
	Petrol p1=new Petrol();
	Electric e1=new Electric();
	Bike b1=new Bike();
	
	
	b1.speed();
	b1.fork();
	b1.gear();
	
	p1.limit();
	p1.gear();
	p1.setname("omkar");
	p1.setNo(1);
	
	e1.capacity();
	e1.useble();
	e1.setname("raj");
	e1.setNo(10);
	
//	upcasting and downcasting for bike and electric
	Bike b2=new Electric();
	Electric e2=(Electric)b2;
	
	b2.speed();
	e2.capacity();
	
//	upcasting and downcasting for bike and petrol
	Bike b3=new Petrol();
	Petrol p3=(Petrol)b3;
	
	b3.speed();
	p3.gear();
	
//	upcasting and downcasting from diffrent packages but if we want to do in
//	diffrent packages then we have to do in subclass every time
	
	Twowheeler t31=new Bike();
	Bike b4=(Bike)t31;
	
	t31.start();
	b4.gear();
	
	Car c1=new Car();
	Petrol_car p11=new Petrol_car();
	Diesel d1=new Diesel();
	Electric_car e11=new Electric_car();
	
	c1.speed();
	c1.seater();
	
	p11.mileage();
	p11.setname("prathmesh");
	p11.setNo(12);
	
	d1.mileage();
	d1.setname("santosh");
	d1.setNo(13);
	
	e11.mileage();
	e11.setname("dinbandhu");
	e11.setNo(15);

	
//	upcasting downcasting from car and petrol
	Car c2=new Petrol_car();
	Petrol_car p2=(Petrol_car)c2;
	
	c2.speed();
	p2.mileage();
	
//	upcasting downcasting from car and diesel
	Car c3=new Diesel();
	Diesel d3=(Diesel)c3;
	
	c3.seater();
	d3.mileage();
	
//	upcasting downcasting from car and electric
	Car c4=new Electric_car();
	Electric_car e4=(Electric_car)c4;
	
	c4.speed();
	e4.mileage();
	
//	upcasting downcasting from car and fourwheeler

	Fourwheeler f2=new Car();
	Car c5=(Car)f2;
	
	f2.start();
	c5.speed();

	
	
	
	}

}
