package vehicle;

public class Fourwheeler extends Vehicle  {
	public void start() {
		System.out.println("i am starting");
	}
	public void stop() {
		System.out.println("i am stoping");
	}
	
}
