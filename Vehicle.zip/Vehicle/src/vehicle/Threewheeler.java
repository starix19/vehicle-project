package vehicle;

public class Threewheeler extends Vehicle {
	void start() {
		System.out.println("i am starting");
	}
	void stop() {
		System.out.println("i am stoping");
	}
}
