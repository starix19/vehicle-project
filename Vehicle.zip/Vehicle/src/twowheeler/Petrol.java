package twowheeler;

public class Petrol extends Bike {
	int speed=200;
	int tankLimit=200;
	int gearCount=5;
	private int no;
	private String name;
	public void limit() {
		System.out.println("tank limit is"+tankLimit);
	}
	public void gear() {
		System.out.println("gear count is"+gearCount);
	}
//	getter setter for id
	public int getNo(){
		return no;
	}
	 public void setNo(int no){
		 this.no=no;
	 }
//	 getter setter for name
	 public String getname(){
			return name;
		}
		 public void setname(String name){
			 this.name=name;
		 }
			
			
		} 

