package twowheeler;

public class Electric extends Bike {
	int capacity=100;
	int usebleHours=10;
	private int no;
	private String name;
	
	public void capacity() {
		System.out.println("capacity is around"+capacity);
	}
	public void useble() {
		System.out.println("useble hours will be "+usebleHours);
	}
	
//	getter setter for id
	public int getNo(){
		return no;
	}
	public void setNo(int no){
		 this.no=no;
	 }
//	 getter setter for name
	public String getname(){
			return name;
		}
	public void setname(String name){
			 this.name=name;
		 } 
		 
		

}
