package twowheeler;

import vehicle.Twowheeler;

public class Bike extends Twowheeler {
	int price=100000;
	int gearCount=4;
	public void speed() {
		System.out.println("speed is 200");
	}
	public void fork() {
		System.out.println("fork is 2");
	}
	public void gear() {
		System.out.println("gear count for bike maximum is"+gearCount);
	}
	
	
}
